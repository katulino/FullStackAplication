package net.guides.springboot2.springboot2postgresqljpahibernatecrudexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot2PostgresqlJpaHibernateCrudExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot2PostgresqlJpaHibernateCrudExampleApplication.class, args);
	}

}
