package net.guides.springboot2.springboot2postgresqljpahibernatecrudexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot2PostgresqlJpaHibernateCrudExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
